const mongoose = require('mongoose');

const fileSchema = new mongoose.Schema({
    subject: String,
    description: String,
    project: { type: String, enum: ['Precio fijo', 'Por hora'], default: 'Precio fijo' },
    budget: Number,
    file: {type: String, required: true} ,
    created: { type: Date, default: Date.now }
});

// create the model for user and expose it to our app
module.exports = mongoose.model('File', fileSchema);