const mongoose = require('mongoose');

const ticketSchema = new mongoose.Schema({
    subject: String,
    description: String,
    image: {type: String, required: true} ,
    priority: { type: String, enum: ['1', '2', '3'], default: '1' },
    created: { type: Date, default: Date.now }
});

// create the model for user and expose it to our app
module.exports = mongoose.model('Ticket', ticketSchema);