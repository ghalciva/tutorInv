module.exports = {  
    'url': 'mongodb://localhost/tutorinv'
};